package com.gabrielphiri.mobilefarmer.upload;

import android.os.Bundle;

import com.gabrielphiri.mobilefarmer.R;

import androidx.appcompat.app.AppCompatActivity;
public class  ViewFlipperMain extends AppCompatActivity {
    @Override
    public  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_flipper_test);
    }
}