package com.gabrielphiri.mobilefarmer.controllers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.gabrielphiri.mobilefarmer.launcher.Login;


public class LogRegPrefManager {
    public static final String SHARED_PREF_NAME = "bwb_account_settings";
    public static final String ID = "id";
    public static final String USERNAME = "username";
    public static final String FULL_NAME = "plumberName";
    public static final String PLAIN_PASSWORD = "plainPassword";
    public static final String ENC_PASSWORD = "encPassword";
    public static final String EMAIL_ADDRESS = "emailAddress";
    public static final String PHONE_NUMBER = "phoneNumber";
    public static final String AREA = "area";
    public static final  String DISTRICT = "district";
    public static final String IS_BUYER = "isBuyer";
    public static final String IS_SELLER = "isSeller";
    public static final String STATUS = "status";
    public static final String IS_FIRST_LOGIN = "isFirstLogin";
    public static final String LOGIN_TIMES = "loginTimes";
    public static final String LAST_LOGIN = "lastLogin";
    public static  final String DATE_ADDED = "dateAdded";
    public static final String IS_ADMIN = "isAdmin";
    public static final String PROFILE_PICTURE = "image";
    public  static  final String NOT_AVAILABLE = "N/A";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static LogRegPrefManager mInstance;
    private static Context mCtx;

    private LogRegPrefManager (Context context) {
        mCtx = context;
    }

    public static synchronized LogRegPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new LogRegPrefManager(context);
        }
        return mInstance;
    }
    public void setPlumberLogin(User userInfo) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(ID, userInfo.getId());
        editor.putString(USERNAME, userInfo.getUsername());
        editor.putString(FULL_NAME, userInfo.getFullName());
        editor.putString(PLAIN_PASSWORD, userInfo.getPlainTextPassword());
        editor.putString(ENC_PASSWORD, userInfo.getPassword());
        editor.putString(EMAIL_ADDRESS, userInfo.getEmailAddress());
        editor.putString(PHONE_NUMBER, userInfo.getPhoneNumber());
        editor.putString(AREA, userInfo.getArea());
        editor.putString(DISTRICT, userInfo.getDistrict());
        editor.putString(IS_BUYER, userInfo.getIsBuyer());
        editor.putString(IS_SELLER, userInfo.getIsSeller());
        editor.putString(DATE_ADDED, userInfo.getDateAdded());
        editor.putString(STATUS, userInfo.getStatus());
        editor.putString(IS_FIRST_LOGIN, userInfo.getIsFirstLogin());
        editor.putString(LAST_LOGIN, userInfo.getLastLogin());
        editor.putString(LOGIN_TIMES, userInfo.getLoginTimes());
        editor.putString(IS_ADMIN, userInfo.getIsAdmin());
        editor.putString(PROFILE_PICTURE, userInfo.getProfilePicture());
        editor.putBoolean(KEY_IS_LOGGED_IN,true);
        editor.apply();
    }
    public boolean isPlumberLoggedIn() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    //this method will give the logged in user
    public User getPlumber() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new User(
                sharedPreferences.getString(ID, "-1"),
                sharedPreferences.getString(USERNAME, null),
                sharedPreferences.getString(FULL_NAME, null),
                sharedPreferences.getString(PLAIN_PASSWORD, null),
                sharedPreferences.getString(ENC_PASSWORD, null),
                sharedPreferences.getString(EMAIL_ADDRESS, null),
                sharedPreferences.getString(PHONE_NUMBER, null),
                sharedPreferences.getString(AREA, null),
                sharedPreferences.getString(DISTRICT, null),
                sharedPreferences.getString(IS_BUYER, "1"),
                sharedPreferences.getString(IS_SELLER, "0"),
                sharedPreferences.getString(DATE_ADDED, null),
                sharedPreferences.getString(STATUS, "1"),
                sharedPreferences.getString(IS_FIRST_LOGIN, "1"),
                sharedPreferences.getString(LOGIN_TIMES, "1"),
                sharedPreferences.getString(LAST_LOGIN, (String) android.text.format.DateFormat.format("yyyy_MM_dd_hh_mm_ss_a", new java.util.Date())),
                sharedPreferences.getString(IS_ADMIN, "0"),
                sharedPreferences.getString(PROFILE_PICTURE, "placeholder.png")
        );
    }
    public void logout() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        mCtx.startActivity(new Intent(mCtx, Login.class));
    }
}
