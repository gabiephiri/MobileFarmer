package com.gabrielphiri.mobilefarmer.data_trans;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.Functions;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.LogRegRequestHandler;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.data_fetch.ListProducts;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import androidx.appcompat.app.AppCompatActivity;

public class AddProduct extends AppCompatActivity {
    EditText addProductNameField, addProductQuantityField, addProductUnitPriceField;
    Spinner addProductCategorySpinner, addProductMetricSpinner;
    Button addProductButton;
    String addProductName, addProductQuantity, addProductUnitPrice, addProductCategory, addProductMetric;
    Functions functions;
    String sellerId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product);
        setTitle(R.string.add_product);
        initViews();
    }
    public void initViews(){
        addProductNameField = findViewById(R.id.addProductNameField);
        addProductQuantityField = findViewById(R.id.addProductQuantityField);
        addProductUnitPriceField = findViewById(R.id.addProductUnitPriceField);
        addProductCategorySpinner = findViewById(R.id.addProductCategorySpinner);
        addProductMetricSpinner = findViewById(R.id.addProductMetricSpinner);
        addProductButton = findViewById(R.id.addProductButton);
        functions = new Functions();
        User sellerIdGetter = LogRegPrefManager.getInstance(this).getUserInfo();
        sellerId = sellerIdGetter.getId();
        ArrayAdapter<CharSequence> productCategoryAdapter  = ArrayAdapter.createFromResource(this,
                R.array.product_category_spinner, android.R.layout.simple_spinner_item);
        productCategoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProductCategorySpinner.setAdapter(productCategoryAdapter);
        ArrayAdapter<CharSequence> productQuantityMetricAdapter  = ArrayAdapter.createFromResource(this,
                R.array.product_quantity_metric_spinner, android.R.layout.simple_spinner_item);
        productQuantityMetricAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProductMetricSpinner.setAdapter(productQuantityMetricAdapter);
        addProductButton.setOnClickListener(v -> {
            setNewProductData();
            addNewProduct();
        });
    }
    public void setNewProductData(){
        addProductName  = addProductNameField.getText().toString();
        addProductQuantity = addProductQuantityField.getText().toString();
        addProductUnitPrice = addProductUnitPriceField.getText().toString();
        int selectedCategoryPosition = addProductCategorySpinner.getSelectedItemPosition();
        int selectedQuantityMetricPosition = addProductMetricSpinner.getSelectedItemPosition();
        addProductCategory = functions.decipherProductCategory(selectedCategoryPosition);
        addProductMetric = functions.decipherMetric(selectedQuantityMetricPosition);
        EditText[] validateReqFields = {addProductNameField, addProductQuantityField, addProductUnitPriceField};
        if(!functions.validateFields(validateReqFields)){
            for (EditText valField: validateReqFields){
                if(valField.getText().toString().isEmpty()){
                    valField.setError("This is required...");
                    valField.requestFocus();
                }
        }
        }

        if(addProductName.isEmpty()){
            addProductNameField.setError("Provide product name");
            addProductNameField.requestFocus();
            return;
        }
        if(addProductQuantity.isEmpty()){
            addProductQuantityField.setError("Provide quantity");
            addProductQuantityField.requestFocus();
        }
        if(addProductUnitPrice.isEmpty()){
            addProductUnitPriceField.setError("Provide unit price");
            addProductUnitPriceField.requestFocus();
            return;
        }
    }

    class AddNewProduct extends AsyncTask<Void, Void, String> {
        ProgressDialog progressDialog;
        String addProductName, addProductCategory,addProductQuantity, addProductQuantityMetric, addProductUnitPrice;
        AddNewProduct(String addProductName, String addProductCategory, String addProductQuantity,
                     String addProductQuantityMetric, String addProductUnitPrice) {
           this.addProductName = addProductName;
           this.addProductCategory = addProductCategory;
           this.addProductQuantity = addProductQuantity;
           this.addProductQuantityMetric = addProductQuantityMetric;
           this.addProductUnitPrice = addProductUnitPrice;

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(AddProduct.this);
            progressDialog.setTitle("Adding New Product...");
            progressDialog.setMessage("Please Wait a moment");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();

            try {
                JSONObject obj = new JSONObject(s);
                if (!obj.getBoolean("errorAvailable") && obj.getBoolean("isAddingProductSuccessful")) {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                    finish();
                    startActivity(new Intent(AddProduct.this, ListProducts.class));
                } else {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        @Override
        protected String doInBackground(Void... voids) {
            LogRegRequestHandler requestHandler = new LogRegRequestHandler();
            HashMap<String, String> params = new HashMap<>();
            params.put("productName", addProductName);
            params.put("productCategory", addProductCategory);
            params.put("productQuantity", addProductQuantity);
            params.put("productQuantityMetric", addProductQuantityMetric);
            params.put("productUnitPrice", addProductUnitPrice);
            params.put("productSellerId", sellerId);
            return requestHandler.sendPostRequest(URLS.ADD_PRODUCT_URL, params);
        }
    }
    private void addNewProduct() {
        AddProduct.AddNewProduct registerUser = new AddProduct.AddNewProduct(addProductName, addProductCategory, addProductQuantity,
                addProductMetric, addProductUnitPrice);
        registerUser.execute();
    }
}
