package com.gabrielphiri.mobilefarmer.launcher;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.Functions;
import com.gabrielphiri.mobilefarmer.controllers.LogRegRequestHandler;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.data_fetch.ProductDetails;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {
    EditText registerFullNameField, registerUsernameField, registerPasswordField, registerPasswordConfirmField,
            registerEmailAddressField, registerPhoneNumberField, registerAreaField, registerDistrictField;
    CheckBox registerIsBuyerCheck, registerIsSellerCheck;
    Button registerUserButton;
    String registerFullName, registerUsername, registerPassword, registerPasswordConfirm, registerEmailAddress,
           registerPhoneNumber, registerArea, registerDistrict, registerIsBuyer = "1", registerIsSeller = "0";
    Functions f ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_user);
        initViews();

    }

    public void initViews(){
        registerFullNameField = findViewById(R.id.registerFullNameField);
        registerUsernameField = findViewById(R.id.registerUsernameField);
        registerPasswordField = findViewById(R.id.registerPasswordField);
        registerPasswordConfirmField = findViewById(R.id.registerPasswordConfirmField);
        registerEmailAddressField = findViewById(R.id.registerEmailAddressField);
        registerPhoneNumberField = findViewById(R.id.registerPhoneNumberField);
        registerAreaField = findViewById(R.id.registerAreaField);
        registerDistrictField = findViewById(R.id.registerDistrictField);
        registerIsBuyerCheck = findViewById(R.id.registerIsBuyerCheck);
        registerIsSellerCheck = findViewById(R.id.registerIsSellerCheck);
        registerUserButton = findViewById(R.id.registerUserButton);
        f = new Functions();

        registerUserButton.setOnClickListener(v -> {
            initViewValues();
            registerUser();
        });
    }

    public void initViewValues(){
        registerFullName = registerFullNameField.getText().toString();
        registerUsername = registerUsernameField.getText().toString();
        registerPassword = registerPasswordField.getText().toString();
        registerPasswordConfirm = registerPasswordConfirmField.getText().toString();
        registerEmailAddress = registerEmailAddressField.getText().toString();
        registerPhoneNumber = registerPhoneNumberField.getText().toString();
        registerArea = registerAreaField.getText().toString();
        registerDistrict = registerDistrictField.getText().toString();
        if(registerIsSellerCheck.isChecked()){registerIsSeller = "1";}
        if(!registerIsBuyerCheck.isChecked()){registerIsBuyer = "0";}

        EditText[] validateFieldsArray = {registerFullNameField, registerUsernameField, registerPasswordConfirmField,
                registerPasswordConfirmField, registerEmailAddressField, registerPhoneNumberField,
                registerAreaField, registerDistrictField};


        if(!f.validateFields(validateFieldsArray)){
            Snackbar.make(getWindow().getDecorView().getRootView(), "Fill all the fields please", Snackbar.LENGTH_LONG).show();
            return;
        }

        if(TextUtils.isEmpty(registerEmailAddress) ||  !f.isValidEmail(registerEmailAddress)){
            registerEmailAddressField.setError("Invalid email");
            registerEmailAddressField.requestFocus();
            return;
        }

        if(!registerPassword.equals(registerPasswordConfirm)){
            registerPasswordConfirmField.setError("Password and confirm do not match");
            registerPasswordConfirmField.requestFocus();
            return;
        }

    }

    class RegisterUser extends AsyncTask<Void, Void, String> {
        ProgressDialog progressDialog;
        String registerFullName, registerUsername, registerPassword, registerEmailAddress, registerPhoneNumber, registerArea,
               registerDistrict, registerIsSeller, registerIsBuyer;
        RegisterUser(String registerFullName,String registerUsername, String registerPassword, String registerEmailAddress, String registerPhoneNumber,
                     String  registerArea, String registerDistrict, String registerIsSeller, String registerIsBuyer) {
            this.registerFullName = registerFullName;
            this.registerUsername = registerUsername;
            this.registerPassword = registerPassword;
            this.registerEmailAddress = registerEmailAddress;
            this.registerPhoneNumber = registerPhoneNumber;
            this.registerArea = registerArea;
            this.registerDistrict =  registerDistrict;
            this.registerIsBuyer = registerIsBuyer;
            this.registerIsSeller = registerIsSeller;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(Register.this);
            progressDialog.setTitle("Processing Registration...");
            progressDialog.setMessage("Please Wait a moment");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();

            try {
                JSONObject obj = new JSONObject(s);
                if (!obj.getBoolean("errorAvailable") && obj.getBoolean("isUserRegistrationSuccessful")) {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                    finish();
                    startActivity(new Intent(Register.this, Login.class));
                } else {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            LogRegRequestHandler requestHandler = new LogRegRequestHandler();
            HashMap<String, String> params = new HashMap<>();
            params.put("registerFullName", registerFullName);
            params.put("registerUsername", registerUsername);
            params.put("registerPassword",registerPassword);
            params.put("registerEmailAddress", registerEmailAddress);
            params.put("registerPhoneNumber", registerPhoneNumber);
            params.put("registerArea", registerArea);
            params.put("registerDistrict", registerDistrict);
            params.put("registerIsSeller", registerIsSeller);
            params.put("registerIsBuyer", registerIsBuyer);
            return requestHandler.sendPostRequest(URLS.REGISTER_USER_URL, params);
        }
    }
    private void registerUser() {
        Register.RegisterUser registerUser = new Register.RegisterUser(registerFullName, registerUsername, registerPassword, registerEmailAddress, registerPhoneNumber,
                registerArea, registerDistrict, registerIsSeller, registerIsBuyer);
        registerUser.execute();
    }

}
