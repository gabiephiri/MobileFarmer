package com.gabrielphiri.mobilefarmer.data_fetch;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.Functions;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.LogRegRequestHandler;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class ProductDetails  extends AppCompatActivity  {
    ImageView productImageDet;
    TextView  productNameDet, productUnitPriceDet, productCategoryDet, productQuantityDet, productSellerNameDet,
            productDateAddedDet, productIdDet;
    EditText productBuyQuantityDet;
    Button productBuyButtonDet;
    String productName, productUnitPrice, productQuantity, productCategory, productSellerName, productId,
            productDateAdded, productStatus, productImage, productBuyQuantity, buyerId;
    Functions functions;
    ConstraintLayout productDetailsConstraintLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_details);
        initViews();
        setProductDetails();
    }

    private void initViews() {
        productIdDet = findViewById(R.id.productIdDet);
        productImageDet = findViewById(R.id.productImageDet);
        productNameDet = findViewById(R.id.productNameDet);
        productUnitPriceDet = findViewById(R.id.productUnitPriceDet);
        productCategoryDet = findViewById(R.id.productCategoryDet);
        productQuantityDet = findViewById(R.id.productQuantityDet);
        productSellerNameDet = findViewById(R.id.productSellerNameDet);
        productDateAddedDet = findViewById(R.id.productDateAddedDet);
        productBuyQuantityDet = findViewById(R.id.productBuyQuantityDet);
        productBuyButtonDet = findViewById(R.id.productBuyButtonDet);
        productDetailsConstraintLayout = findViewById(R.id.productDetailsConstraiintLayout);

    }


    public void setProductDetails(){
        Intent getProductDetails  = getIntent();
         productName = getProductDetails.getStringExtra("productName");
         productDateAdded = getProductDetails.getStringExtra("productDateAdded");
         productCategory = getProductDetails.getStringExtra("productCategory");
         productUnitPrice = getProductDetails.getStringExtra("productUnitPrice");
         productSellerName = getProductDetails.getStringExtra("productSellerName");
         productQuantity = getProductDetails.getStringExtra("productQuantity");
         productStatus = getProductDetails.getStringExtra("productStatus");
         productImage = getProductDetails.getStringExtra("productImage");
         User user = LogRegPrefManager.getInstance(this).getUserInfo();
         buyerId = user.getId();
         productId = getProductDetails.getStringExtra("productId");
         productNameDet.setText(productName);
         productDateAddedDet.setText(productDateAdded);
         productCategoryDet.setText(productCategory);
         productUnitPriceDet.setText(String.format("@%s", productUnitPrice));
         productSellerNameDet.setText(productSellerName);
         productQuantityDet.setText(productQuantity);
         productBuyQuantityDet.setText(productBuyQuantity);
         productIdDet.setText(productId);
         Picasso.with(this).load(URLS.PRODUCT_IMAGES_URL+productImage)
                .fit()
                .centerCrop()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder)
                .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                .into(productImageDet) ;
        productBuyButtonDet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                productBuyQuantity = productBuyQuantityDet.getText().toString();

                if(Float.parseFloat(productQuantity) > Float.parseFloat(productBuyQuantity)){

                    ProductDetails.BuyProduct buyProduct = new ProductDetails.BuyProduct(productId, buyerId, productBuyQuantity);
                    buyProduct.execute();
                }
                else{
                    Snackbar.make(getWindow().getDecorView().getRootView(), "Available Quantity is less than requested purchase quantity", Snackbar.LENGTH_LONG).show();

                }
//
            }
        });
    }

    class BuyProduct extends AsyncTask<Void, Void, String> {
            ProgressDialog progressDialog;
            String productId, buyerId, buyQuantity;
            BuyProduct(String productId,String buyerId, String buyQuantity) {
                this.productId = productId;
                this.buyerId = buyerId;
                this.buyQuantity = buyQuantity;

            }
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(ProductDetails.this);
                progressDialog.setTitle("Processing transaction...");
                progressDialog.setMessage("Please Wait a moment");
                progressDialog.setCancelable(false);
                progressDialog.show();
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                functions = new Functions();

                try {
                    JSONObject obj = new JSONObject(s);
                    if (!obj.getBoolean("errorAvailable") && obj.getBoolean("isPurchaseSuccessful")) {
                        hideKeyBoard();
                       Snackbar.make(productDetailsConstraintLayout, "Purchase Complete", Snackbar.LENGTH_LONG).show();
                    } else {
                        Snackbar.make(productDetailsConstraintLayout, obj.getString("message"), Snackbar.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                LogRegRequestHandler requestHandler = new LogRegRequestHandler();
                HashMap<String, String> params = new HashMap<>();
                params.put("productId", productId);
                params.put("buyerId", buyerId);
                params.put("buyQuantity", productBuyQuantity);
                return requestHandler.sendPostRequest(URLS.PURCHASE_PRODUCT_URL, params);
            }
    }

    public void hideKeyBoard(){
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }


}
