package com.gabrielphiri.mobilefarmer.data_fetch;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gabrielphiri.mobilefarmer.R;

import java.util.List;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


public class ProductsListAdapter extends RecyclerView.Adapter<ProductsListAdapter.ViewHolder> {
    private List<ProductListModel> developersLists;
    private Context context;
    ProductsListAdapter(List<ProductListModel> developersLists, Context context) {
        this.developersLists = developersLists;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // this method will be called whenever our ViewHolder is created
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.products_list, parent, false);
        return new ViewHolder(v);
    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        // this method will bind the data to the ViewHolder from whence it'll be shown to other Views
        final ProductListModel developersList = developersLists.get(position);
        holder.productNameView.setText(developersList.getProductName());
        holder.productDateAddedView.setText(developersList.getProductDateAdded()); //get fault date added
        holder.productCategoryView.setText(developersList.getProductCategory()); //get fault location
        holder.productSellerNameView.setText(developersList.getProductSellerName());
        holder.productUnitPriceView.setText(developersList.getProductUnitPrice());
        holder.productQuantityView.setText(developersList.getProductQuantity());
        holder.productStatusView.setText(developersList.getProductStatus()); //get fault status
        holder.productImageView.setText(developersList.getProductImage());
        holder.productImageAfterView.setText(developersList.getProductImageAfter());
        holder.productIdView.setText(developersList.getProductId());
        if(holder.productSellerNameView.getText().toString().equalsIgnoreCase("0")){
            holder.productStatusView.setTextColor(Color.parseColor("#FF0000"));
        }

        /* here we implement the logic to get the current details of the fault and post them to the next activity
         * for editing the fault
         */
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startEditFaults(holder, v);
            }
        });

       /**
        * Picasso.with(context)
                .load(developersList.getAvatar_url())
                .into(holder.avatar_url);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProductListModel developersList1 = developersLists.get(position);
                Intent skipIntent = new Intent(v.getContext(), FaultDetails.class);
                skipIntent.putExtra(KEY_NAME, developersList1.getFaultLocation());
                skipIntent.putExtra(KEY_URL, developersList1.getFaultDateReceived());
                v.getContext().startActivity(skipIntent);
            }
        }); **/

//       holder.faultListMenuButton.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(final View v) {
//               PopupMenu faultListMenu = new PopupMenu(context, holder.faultListMenuButton);
//               faultListMenu.inflate(R.menu.product_list_menu);
//               faultListMenu.show();
//                faultListMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//               @Override
//               public boolean onMenuItemClick(MenuItem item) {
//                   int itemId = item.getItemId();
//               switch(itemId) {
//                       case R.id.markFaultAsCompleted:
//                           {
//                               Intent startClearingFault = new Intent(context, ListProducts.class);
//                               context.startActivity(startClearingFault);
//
//                           break;
//                          }
//                   case R.id.editFault:
//                       {
//                       startEditFaults(holder, v);
//                       break;
//                       }
//               }
//               return false;
//               }
//               });
//                faultListMenu.show();
//
//           }
//       });


    }

    @Override
    //return the size of the listItems (developersList)
    public int getItemCount() {
        return developersLists.size();
    }
    static class ViewHolder extends RecyclerView.ViewHolder  {
        // define the View objects
        TextView productNameView;
        TextView productDateAddedView;
        TextView productCategoryView;
        TextView productSellerNameView;
        TextView productUnitPriceView;
        TextView productQuantityView;
        TextView productStatusView;
        TextView productImageView;
        TextView productImageAfterView;
        TextView productIdView;
        TextView faultListMenuButton;
        RelativeLayout linearLayout;

        CardView cardView;
        ViewHolder(View itemView) {
            super(itemView);
            productNameView = itemView.findViewById(R.id.productNameView);
            productDateAddedView = itemView.findViewById(R.id.productDateAddedView);
            productCategoryView = itemView.findViewById(R.id.productCategoryView);
            productUnitPriceView = itemView.findViewById(R.id.productPriceView);
            productSellerNameView = itemView.findViewById(R.id.productSellerNameView);
            faultListMenuButton = itemView.findViewById(R.id.productListMenuButton);
            linearLayout = itemView.findViewById(R.id.faultDetailsRelativeLayout);
            productQuantityView =  itemView.findViewById(R.id.productQuantityView);
            productStatusView = itemView.findViewById(R.id.productStatusView);
            productImageView = itemView.findViewById(R.id.productImageView);
            productImageAfterView = itemView.findViewById(R.id.productImageAfterView);
            productIdView = itemView.findViewById(R.id.productIdView);
            cardView = itemView.findViewById(R.id.faultsListCardView);
        }

    }

    public void startEditFaults(ViewHolder holder, View v){
        Intent editFaultIntent = new Intent(context, ProductDetails.class);
        editFaultIntent.putExtra("productName", holder.productNameView.getText().toString());
        editFaultIntent.putExtra("productDateAdded", holder.productDateAddedView.getText().toString());
        editFaultIntent.putExtra("productCategory", holder.productCategoryView.getText().toString());
        editFaultIntent.putExtra("productUnitPrice", holder.productUnitPriceView.getText().toString());
        editFaultIntent.putExtra("productSellerName", holder.productSellerNameView.getText().toString());
        editFaultIntent.putExtra("productQuantity", holder.productQuantityView.getText().toString());
        editFaultIntent.putExtra("productStatus", holder.productStatusView.getText().toString());
        editFaultIntent.putExtra("productImage", holder.productImageView.getText().toString());
        editFaultIntent.putExtra("productImageAfter", holder.productImageAfterView.getText().toString());
        editFaultIntent.putExtra("productId", holder.productIdView.getText().toString());
        v.getContext().startActivity(editFaultIntent);

    }

    /**start processing clearance **/


}
