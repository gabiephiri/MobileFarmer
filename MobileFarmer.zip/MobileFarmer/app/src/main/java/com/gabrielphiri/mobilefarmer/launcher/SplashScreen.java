package com.gabrielphiri.mobilefarmer.launcher;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;

import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.data_fetch.UserProfile;

import androidx.appcompat.app.AppCompatActivity;


public class SplashScreen extends AppCompatActivity {
    private Handler mWaitHandler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        mWaitHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent startMainActivity = new Intent (SplashScreen.this, Login.class);
                startActivity(startMainActivity);
                finish();
            }
        }, 3000);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        mWaitHandler.removeCallbacksAndMessages(null);
    }
}