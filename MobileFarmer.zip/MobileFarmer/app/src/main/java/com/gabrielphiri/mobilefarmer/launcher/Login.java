package com.gabrielphiri.mobilefarmer.launcher;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;

import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.LogRegRequestHandler;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;



public class Login extends AppCompatActivity {
    EditText loginUsernameField, loginPasswordField;
    Button loginButton;
    ScrollView loginScrollView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initLoginView();
    }
    public void initLoginView(){
        loginUsernameField = findViewById(R.id.loginUsernameField);
        loginPasswordField = findViewById(R.id.loginPasswordField);
        loginButton = findViewById(R.id.loginButton);
        loginScrollView = findViewById(R.id.loginScrollView);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userLogin();
            }
        });
    }
    private void userLogin() {
        //first getting the values
        final String username = loginUsernameField.getText().toString();
        final String password = loginPasswordField.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(username)) {
            loginUsernameField.setError("Please enter username");
            loginUsernameField.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            loginPasswordField.setError("Please enter password");
            loginPasswordField.requestFocus();
            return;
        }
        //if everything is fine
        UserLogin pl = new UserLogin(username,password);
        pl.execute();
    }
    class UserLogin extends AsyncTask<Void, Void, String> {
        ProgressDialog progressDialog;
        String username, password;
        UserLogin(String username, String password) {
            this.username = username;
            this.password = password;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(Login.this);
            progressDialog.setTitle("Logging in");
            progressDialog.setMessage("Please Wait a moment");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                //converting response to json object
                JSONObject obj = new JSONObject(s);
                if (!obj.getBoolean("errorAvailable") & obj.getBoolean("isLoginSuccessful")) {
                    JSONArray jsonArray = obj.getJSONArray("userInfo");
                    JSONObject userInfo = jsonArray.getJSONObject(0);
                    String id = userInfo.getString("id");
                    String fullName = userInfo.getString("fullName");
                    String username = userInfo.getString("username");
                    String password = userInfo.getString("password");
                    String plainTextPassword = obj.getString("plainPassword");
                    String emailAddress = userInfo.getString("emailAddress");
                    String phoneNumber = userInfo.getString("phoneNumber");
                    String area = userInfo.getString("area");
                    String district = userInfo.getString("district");
                    String isBuyer = userInfo.getString("isBuyer");
                    String isSeller = userInfo.getString("isSeller");
                    String dateAdded = userInfo.getString("dateAdded");
                    String status = userInfo.getString("status");
                    String isFirstLogin = userInfo.getString("isFirstLogin");
                    String loginTimes = userInfo.getString("loginTimes");
                    String lastLogin = userInfo.getString("lastLogin");
                    String isAdmin = userInfo.getString("isAdmin");
                    String profilePicture = userInfo.getString("profilePicture");

               User saveUserInfo = new User(id, fullName, username, password, plainTextPassword,
                            emailAddress, phoneNumber, area, district, isBuyer, isSeller, dateAdded, status,
                    isFirstLogin, loginTimes, lastLogin, isAdmin, profilePicture);
                    LogRegPrefManager.getInstance(getApplicationContext()).setPlumberLogin(saveUserInfo);
                    finish();
                 startActivity(new Intent(Login.this, Redirector.class));
                } else {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            //creating request handler object
            LogRegRequestHandler requestHandler = new LogRegRequestHandler();
            //creating request parameters
            HashMap<String, String> params = new HashMap<>();
            params.put("username", username);
            params.put("password", password);

            //returning the response
            return requestHandler.sendPostRequest(URLS.LOGIN_URL, params);
        }
    }

}
