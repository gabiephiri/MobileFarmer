package com.gabrielphiri.mobilefarmer.launcher;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.Functions;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.data_fetch.ListProducts;
import com.gabrielphiri.mobilefarmer.data_fetch.UserProfile;
import com.gabrielphiri.mobilefarmer.data_trans.AddProduct;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class Home  extends AppCompatActivity {
   TextView homeListProducts, homeAddProduct, homeRegister, homeLogin, homeProfile, homeLogout;
   Functions functions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        initViews();
    }

    public void initViews(){
        functions = new Functions();
        homeListProducts = findViewById(R.id.homeListProducts);
        homeAddProduct = findViewById(R.id.homeAddProduct);
        homeRegister = findViewById(R.id.homeRegister);
        homeLogin = findViewById(R.id.homeLogin);
        homeProfile = findViewById(R.id.homeProfile);
        homeLogout = findViewById(R.id.homeLogout);
        LogRegPrefManager.getInstance(this).logout();
        homeListProducts.setOnClickListener(v -> startActivity(new Intent(Home.this, ListProducts.class)));
        homeAddProduct.setOnClickListener(v -> startActivity(new Intent(Home.this, AddProduct.class)));
        homeRegister.setOnClickListener(v -> startActivity(new Intent(Home.this, Register.class)));
        homeLogin.setOnClickListener(v -> startActivity(new Intent(Home.this, Login.class)));
        homeProfile.setOnClickListener(v -> startActivity(new Intent(Home.this, UserProfile.class)));
        homeLogout.setOnClickListener(v -> {
            LogRegPrefManager.getInstance(this).logout();
            startActivity(new Intent(this, Login.class));
        });
    }

}
