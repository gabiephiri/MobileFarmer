package com.gabrielphiri.mobilefarmer.data_fetch;

class ProductListModel {

    private String productName;
    private String productDateAdded;
    private  String productCategory;
    private String productSellerName;
    private String productUnitPrice;
    private String productQuantity;
    private String productStatus;
    private String productImage;
    private String productImageAfter;
    private String productId;

    ProductListModel(String productName, String productDateAdded, String productCategory, String productSellerName,
                     String productUnitPrice, String productQuantity, String productStatus, String productImage,
                     String productImageAfter , String productId) {
       this.productName = productName;
       this.productDateAdded = productDateAdded;
       this.productCategory = productCategory;
       this.productSellerName = productSellerName;
       this.productUnitPrice = productUnitPrice;
       this.productQuantity = productQuantity;
       this.productStatus = productStatus;
       this.productImage = productImage;
       this.productImageAfter = productImageAfter;
       this.productId = productId;
    }


    public String getProductId() { return productId; }
    public String getProductName(){return  productName;}
    public String getProductDateAdded(){return productDateAdded;}
    public String getProductCategory(){return productCategory;}
    public String getProductSellerName(){return productSellerName;}
    public String getProductUnitPrice(){return productUnitPrice;}
    public String getProductQuantity(){return productQuantity;}
    public String getProductStatus(){return productStatus;}
    public String getProductImage(){return productImage;}
    public String getProductImageAfter(){return  productImageAfter;}


}