package com.gabrielphiri.mobilefarmer.launcher;

import android.content.Intent;
import android.os.Bundle;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.data_fetch.ListProducts;
import androidx.appcompat.app.AppCompatActivity;



public class Redirector extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        User user = LogRegPrefManager.getInstance(this).getUserInfo();
        String buyerId = user.getId();
        if(!buyerId.isEmpty()){
            startActivity(new Intent(this, ListProducts.class));
        }
        else{
            startActivity(new Intent(this, Login.class));
        }
        finish();
    }
}


