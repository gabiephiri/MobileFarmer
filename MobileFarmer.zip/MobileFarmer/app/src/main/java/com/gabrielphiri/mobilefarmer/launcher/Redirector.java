package com.gabrielphiri.mobilefarmer.launcher;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.gabrielphiri.mobilefarmer.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.SHARED_PREF_NAME;


public class Redirector extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        sharedPreferences = this.getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        if(sharedPreferences.contains("plumberId")){
            startActivity(new Intent(this, ListProducts.class));
        }
        else{
            startActivity(new Intent(this, Login.class));
        }
        finish();
    }
}


