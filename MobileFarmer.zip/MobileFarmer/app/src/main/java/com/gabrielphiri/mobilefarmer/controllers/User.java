package com.gabrielphiri.mobilefarmer.controllers;
public class User {
private String fullName, username, password, plainTextPassword, emailAddress, phoneNumber, area, district, dateAdded, lastLogin;
    private int  id, isBuyer, isSeller, status, isFirstLogin, loginTimes,  isAdmin;
    public User(int id, String fullName, String username, String password, String plainTextPassword, String emailAddress,
                String phoneNumber, String area, String district, int isBuyer, int isSeller, String dateAdded, int status,
                int isFirstLogin, int loginTimes, String lastLogin, int isAdmin)
    {
        this.id = id;
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.plainTextPassword = plainTextPassword;
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
        this.area = area;
        this.district = district;
        this.isBuyer = isBuyer;
        this.isSeller = isSeller;
        this.dateAdded = dateAdded;
        this.isFirstLogin = isFirstLogin;
        this.loginTimes = loginTimes;
        this.isAdmin = isAdmin;
        this.lastLogin = lastLogin;

    }
   public int getId(){return  id;}
   public String getFullName(){return fullName;}
   public String getUsername(){return username;}
   public String getPassword() { return password; }
   public String getPlainTextPassword() { return plainTextPassword; }
   public String getPhoneNumber() { return phoneNumber; }
   public String getArea() { return area; }
   public String getDistrict() { return district; }
   public int getIsBuyer() { return isBuyer; }
   public int getIsSeller() { return isSeller; }
   public String getDateAdded() { return dateAdded; }
   public int getStatus() { return status; }
   public int getIsFirstLogin() { return isFirstLogin; }
   public int getLoginTimes() { return loginTimes; }
   public int getIsAdmin() { return isAdmin; }
   public String getEmailAddress() { return emailAddress; }

    public String getLastLogin() { return lastLogin;
    }
}
