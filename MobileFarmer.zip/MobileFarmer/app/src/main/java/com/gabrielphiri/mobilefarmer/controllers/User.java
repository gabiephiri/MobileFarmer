package com.gabrielphiri.mobilefarmer.controllers;
public class User {
private String fullName, username, password, plainTextPassword, emailAddress, phoneNumber, area, district, dateAdded, lastLogin,
        id, isBuyer, isSeller, status, isFirstLogin, loginTimes,  isAdmin, profilePicture;
    public User(String id, String fullName, String username, String password, String plainTextPassword, String emailAddress,
                String phoneNumber, String area, String district, String isBuyer, String isSeller, String dateAdded, String status,
                String isFirstLogin, String loginTimes, String lastLogin, String isAdmin, String profilePicture)
    {
        this.id = id;
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.plainTextPassword = plainTextPassword;
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
        this.area = area;
        this.district = district;
        this.isBuyer = isBuyer;
        this.isSeller = isSeller;
        this.dateAdded = dateAdded;
        this.isFirstLogin = isFirstLogin;
        this.loginTimes = loginTimes;
        this.isAdmin = isAdmin;
        this.lastLogin = lastLogin;
        this.profilePicture = profilePicture;
         this.status = status;

    }
   public String getId(){return  id;}
   public String getFullName(){return fullName;}
   public String getUsername(){return username;}
   public String getPassword() { return password; }
   public String getPlainTextPassword() { return plainTextPassword; }
   public String getPhoneNumber() { return phoneNumber; }
   public String getArea() { return area; }
   public String getDistrict() { return district; }
   public String getIsBuyer() { return isBuyer; }
   public String getIsSeller() { return isSeller; }
   public String getDateAdded() { return dateAdded; }
   public String getStatus() { return status; }
   public String getIsFirstLogin() { return isFirstLogin; }
   public String getLoginTimes() { return loginTimes; }
   public String getIsAdmin() { return isAdmin; }
   public String getEmailAddress() { return emailAddress; }
    public String getLastLogin() { return lastLogin;}
    public String getProfilePicture(){return profilePicture;}

}
