package com.gabrielphiri.mobilefarmer.data_fetch;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.data_trans.AddProduct;
import com.gabrielphiri.mobilefarmer.launcher.Home;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.IS_SELLER;
import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.SHARED_PREF_NAME;


public class ListProducts extends AppCompatActivity {

    private RecyclerView recyclerView;
    FloatingActionButton addFaultFab;
    private RecyclerView.Adapter adapter;
    private List<ProductListModel> developersLists;
    Toolbar listFaultsToolbar;
    RelativeLayout flRl;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_list_recycler_view);
        setTitle("Products");
        recyclerView =  findViewById(R.id.recyclerView);
        flRl = findViewById(R.id.flRl);
        addFaultFab = findViewById(R.id.addFaultFab);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        String isSeller = sharedPreferences.getString(IS_SELLER, "0");
        addFaultFab.setOnClickListener(v -> {
            if(sharedPreferences.contains(IS_SELLER) && isSeller.equals("1")){
                startActivity(new Intent(ListProducts.this, AddProduct.class));
            }
            else{
                Snackbar.make(getWindow().getDecorView().getRootView(), "You do not have permission to sell products", Snackbar.LENGTH_LONG).show();
            }
        });
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        developersLists = new ArrayList<>();
        loadUrlData();
    }
    private void loadUrlData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading products...");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URLS.LIST_PRODUCTS_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("productsList");
                    for (int i = 0; i < array.length(); i++){
                        JSONObject jo = array.getJSONObject(i);
                        ProductListModel developers =  new ProductListModel(jo.getString("name"), jo.getString("dateAdded"),
                                jo.getString("category"), jo.getString("sellerName"),
                                jo.getString("unitPrice"), jo.getString("quantity"), jo.getString("status"), jo.getString("image"),
                                jo.getString("image") , jo.getString("id"));

                        developersLists.add(developers);
                    }
                    adapter = new ProductsListAdapter(developersLists, getApplicationContext());
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ListProducts.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.common_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        switch(itemId){
            case R.id.userProfile:{
                startActivity(new Intent(this, UserProfile.class));
                break;
            }
            case R.id.sales:{
                startActivity(new Intent(this, SalesList.class));
                break;
            }
            case R.id.purchases:{
                startActivity(new Intent(this, Purchases.class));
                break;
            }
            case R.id.home:{
                startActivity(new Intent(this, Home.class));
                break;
            }

        }
        return true;
    }
}

