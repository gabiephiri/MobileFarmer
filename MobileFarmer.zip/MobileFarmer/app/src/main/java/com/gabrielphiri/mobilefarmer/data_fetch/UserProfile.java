package com.gabrielphiri.mobilefarmer.data_fetch;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.gabrielphiri.mobilefarmer.controllers.Functions;
import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.LogRegRequestHandler;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.launcher.Login;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class UserProfile  extends AppCompatActivity {
    ImageView userImageDet;
    TextView fullNameDet, usernameDet, emailAddressDet, phoneNumberDet, areaDet, districtDet, isBuyerDet, isSellerDet, statusDet,
            isFirstLoginDet, loginTimesDet, lastLoginDet, isAdminDet, dateAddedDet, plainPasswordDet, userIdDet, requestFullTrade;
    Functions functions;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.user_profile);
        setTitle(R.string.user_profile);
        super.onCreate(savedInstanceState);
        initViews();
        setUserDetails();
    }

    private void initViews() {
        fullNameDet = findViewById(R.id.fullNameDet);
        usernameDet = findViewById(R.id.usernameDet);
        emailAddressDet = findViewById(R.id.emailAddressDet);
        phoneNumberDet = findViewById(R.id.phoneNumberDet);
        areaDet = findViewById(R.id.areaDet);
        districtDet = findViewById(R.id.districtDet);
        isBuyerDet = findViewById(R.id.isBuyerDet);
        isSellerDet = findViewById(R.id.isSellerDet);
        statusDet = findViewById(R.id.statusDet);
        isFirstLoginDet = findViewById(R.id.isFirstLoginDet);
        loginTimesDet = findViewById(R.id.loginTimesDet);
        lastLoginDet = findViewById(R.id.lastLoginDet);
        isAdminDet = findViewById(R.id.isAdminDet);
        dateAddedDet = findViewById(R.id.dateAddedDet);
        plainPasswordDet = findViewById(R.id.plainPasswordDet);
        userIdDet = findViewById(R.id.userIdDet);
        userImageDet = findViewById(R.id.userImageDet);
        requestFullTrade = findViewById(R.id.requestFullTrade);
        requestFullTrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserProfile.GetFullAccess gua = new UserProfile.GetFullAccess(user.getId());
                gua.execute();
            }
        });

    }


    public void setUserDetails() {
        functions = new Functions();
      user = LogRegPrefManager.getInstance(this).getUserInfo();
        fullNameDet.setText(String.format("Name: %s", user.getUsername()));
        usernameDet.setText(String.format("Username: %s", user.getFullName()));
        emailAddressDet.setText(String.format("Email: %s", user.getEmailAddress()));
        phoneNumberDet.setText(String.format("Phone: %s", user.getPhoneNumber()));
        areaDet.setText(String.format("Area: %s", user.getArea()));
        districtDet.setText(String.format("District:%s", user.getDistrict()));
        isBuyerDet.setText(String.format("Is Buyer: %s", functions.getYesNo(user.getIsBuyer())));
        isSellerDet.setText(String.format("Is Seller: %s", functions.getYesNo(user.getIsSeller())));
        statusDet.setText(String.format("Status: %s", functions.echoStatus(user.getStatus())));
        isFirstLoginDet.setText(String.format("First Login: %s", functions.getYesNo(user.getIsFirstLogin())));
        loginTimesDet.setText(String.format("Login Times: %s", user.getLoginTimes()));
        lastLoginDet.setText(String.format("Last Login: %s", user.getLastLogin()));
        isAdminDet.setText(String.format("Is Admin: %s", functions.getYesNo(user.getIsAdmin())));
        dateAddedDet.setText(String.format("Reg Date: %s", user.getDateAdded()));
        plainPasswordDet.setText(String.format("Mock Pw: %s", user.getPlainTextPassword()));
        userIdDet.setText(user.getId());

        Picasso.with(this).load(URLS.USER_IMAGES_URL + user.getProfilePicture())
                .placeholder(R.drawable.placeholder).error(R.drawable.placeholder).fit()
                .centerCrop().memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE).into(userImageDet);


    }

    class GetFullAccess extends AsyncTask<Void, Void, String> {
        ProgressDialog progressDialog;
        String userId;
        GetFullAccess(String userId) {
            this.userId = userId;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(UserProfile.this);
            progressDialog.setTitle("Processing transaction...");
            progressDialog.setMessage("Please Wait a moment");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            functions = new Functions();

            try {
                JSONObject obj = new JSONObject(s);
                if (!obj.getBoolean("errorAvailable") && obj.getBoolean("isUserFullTrader")) {
                    Snackbar.make(getWindow().getDecorView().getRootView(), "Success! User is both buyer and seller now", Snackbar.LENGTH_LONG).show();
                } else {
                    Snackbar.make(getWindow().getDecorView().getRootView(), obj.getString("message"), Snackbar.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        @Override
        protected String doInBackground(Void... voids) {
            LogRegRequestHandler requestHandler = new LogRegRequestHandler();
            HashMap<String, String> params = new HashMap<>();
            params.put("userId", user.getId());
            return requestHandler.sendPostRequest(URLS.GRANT_FULL_TRADE_URL, params);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
     MenuInflater inflater = getMenuInflater();
     inflater.inflate(R.menu.common_menu, menu);
     MenuItem userProfileItem= menu.findItem(R.id.userProfile);
     MenuItem logoutItem = menu.getItem(R.id.logout);
     MenuItem homeItem = menu.getItem(R.id.home);
     userProfileItem.setVisible(false);
     logoutItem.setVisible(false);
     homeItem.setVisible(false);
     return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemId = item.getItemId();
        switch (itemId){
            case R.id.purchases:{
                startActivity(new Intent(this, Purchases.class));
                break;
            }
            case R.id.sales:{
                startActivity(new Intent(this, SalesList.class));
                break;
            }

        }
        return true;
    }


}
