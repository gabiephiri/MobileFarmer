package com.gabrielphiri.mobilefarmer.data_fetch;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import com.gabrielphiri.mobilefarmer.controllers.Functions;

import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class UserProfile  extends AppCompatActivity {
    ImageView userImageDet;
    TextView fullNameDet, usernameDet, emailAddressDet, phoneNumberDet, areaDet, districtDet, isBuyerDet, isSellerDet, statusDet,
    isFirstLoginDet, loginTimesDet, lastLoginDet, isAdminDet, dateAddedDet, plainPasswordDet, userIdDet;
    Functions functions;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.user_profile);
        super.onCreate(savedInstanceState);
        initViews();
        setUserDetails();
    }

    private void initViews() {
        fullNameDet = findViewById(R.id.fullNameDet);
        usernameDet = findViewById(R.id.usernameDet);
        emailAddressDet = findViewById(R.id.emailAddressDet);
        phoneNumberDet = findViewById(R.id.phoneNumberDet);
        areaDet = findViewById(R.id.areaDet);
        districtDet = findViewById(R.id.districtDet);
        isBuyerDet = findViewById(R.id.isBuyerDet);
        isSellerDet = findViewById(R.id.isSellerDet);
        statusDet = findViewById(R.id.statusDet);
        isFirstLoginDet = findViewById(R.id.isFirstLoginDet);
        loginTimesDet = findViewById(R.id.loginTimesDet);
        lastLoginDet = findViewById(R.id.lastLoginDet);
        isAdminDet = findViewById(R.id.isAdminDet);
        dateAddedDet = findViewById(R.id.dateAddedDet);
        plainPasswordDet = findViewById(R.id.plainPasswordDet);
        userIdDet = findViewById(R.id.userIdDet);
        userImageDet = findViewById(R.id.userImageDet);

    }

    public void setUserDetails(){
        functions = new Functions();
        User user = LogRegPrefManager.getInstance(this).getPlumber();
        fullNameDet.setText(String.format("Name: %s", user.getFullName()));
        usernameDet.setText(String.format("Username: %s", user.getUsername()));
        emailAddressDet.setText(String.format("Email: %s", user.getEmailAddress()));
        phoneNumberDet.setText(String.format("Phone: %s", user.getPhoneNumber()));
        areaDet.setText(String.format("Area: %s", user.getArea()));
        districtDet.setText(String.format("District:%s", user.getDistrict()));
        isBuyerDet.setText(String.format("Is Buyer: %s", functions.getYesNo(user.getIsBuyer())));
        isSellerDet.setText(String.format("Is Seller: %s", functions.getYesNo(user.getIsSeller())));
        statusDet.setText(String.format("Status: %s", functions.echoStatus(user.getStatus())));
        isFirstLoginDet.setText(String.format("First Login: %s", functions.getYesNo(user.getIsFirstLogin())));
        loginTimesDet.setText(String.format("Login Times: %s", user.getLoginTimes()));
        lastLoginDet.setText(String.format("Last Login: %s", user.getLastLogin()));
        isAdminDet.setText(String.format("Is Admin: %s", functions.getYesNo(user.getIsAdmin())));
        dateAddedDet.setText(String.format("Reg Date: %s", user.getDateAdded()));
        plainPasswordDet.setText(String.format("Mock Pw: %s", user.getPlainTextPassword()));
        userIdDet.setText(user.getId());

        Picasso.with(this).load(URLS.USER_IMAGES_URL+user.getProfilePicture())
                .placeholder(R.drawable.placeholder).error(R.drawable.placeholder).fit()
                .centerCrop().memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE).into(userImageDet);


    }
}
