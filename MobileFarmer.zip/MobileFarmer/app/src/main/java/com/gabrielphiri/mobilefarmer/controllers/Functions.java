package com.gabrielphiri.mobilefarmer.controllers;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import static android.content.Context.MODE_PRIVATE;
import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.*;
public class Functions  {
    public Functions(){}
        public void resetFields(EditText[] fields)
        {
            for(EditText e : fields)
            {
                e.setText("");
            }
        }

    private void returnToActivity(Context context, Class toClass){
        Intent intent = new Intent(context,toClass);
        context.startActivity(intent);
    }

    public void loadProfile (Context context, TextView nameView, TextView usernameView, TextView statusView, TextView stampDateView,
                             TextView stampUserView, TextView zoneView, TextView lastLoginView, TextView loginTimesView)
    {
        SharedPreferences profilePreferences = context.getSharedPreferences( SHARED_PREF_NAME, MODE_PRIVATE);

        if(profilePreferences != null) {
            if (profilePreferences.contains(FULL_NAME)) {
                nameView.setText(profilePreferences.getString(FULL_NAME, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(USERNAME)) {
                usernameView.setText(profilePreferences.getString(USERNAME, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(STATUS)) {
                statusView.setText(profilePreferences.getInt(STATUS, -1));
            }
            if (profilePreferences.contains(DATE_ADDED)) {
                stampDateView.setText(profilePreferences.getString(DATE_ADDED, NOT_AVAILABLE));
            }

            if (profilePreferences.contains(LAST_LOGIN)) {
                lastLoginView.setText(profilePreferences.getString(LAST_LOGIN, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(LOGIN_TIMES)) {
                loginTimesView.setText(profilePreferences.getInt(LOGIN_TIMES, -1));
            }
        }

    }
    public  String  echoStatus(String statusCode){
        String state = NOT_AVAILABLE;
       if(!statusCode.equals("")){
           if(statusCode.equals("1")){
               state = "Active";
           }
           else{
               state = "Inactive";
           }
       }
       return state;
    }
    public String getYesNo (String boolValue){
        String yesNo = NOT_AVAILABLE;
        if(!boolValue.equals("") && !boolValue.equals("null") && !boolValue.isEmpty()){
            if(boolValue.equals("1")){
                yesNo = "Yes";
            }
            else{
                yesNo = "No";
            }
        }
        return yesNo;
    }


    }





