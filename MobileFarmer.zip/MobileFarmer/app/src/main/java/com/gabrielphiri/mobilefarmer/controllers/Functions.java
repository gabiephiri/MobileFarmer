package com.gabrielphiri.mobilefarmer.controllers;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import org.w3c.dom.Text;

import androidx.appcompat.app.AppCompatActivity;

import static android.content.Context.MODE_PRIVATE;
import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.*;
public class Functions  {
    public Functions(){}
        public void resetFields(EditText[] fields)
        {
            for(EditText e : fields)
            {
                e.setText("");
            }
        }

    private void returnToActivity(Context context, Class toClass){
        Intent intent = new Intent(context,toClass);
        context.startActivity(intent);
    }

    public void loadProfile (Context context, TextView nameView, TextView usernameView, TextView statusView, TextView stampDateView,
                             TextView stampUserView, TextView zoneView, TextView lastLoginView, TextView loginTimesView)
    {
        SharedPreferences profilePreferences = context.getSharedPreferences( SHARED_PREF_NAME, MODE_PRIVATE);

        if(profilePreferences != null) {
            if (profilePreferences.contains(FULL_NAME)) {
                nameView.setText(profilePreferences.getString(FULL_NAME, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(USERNAME)) {
                usernameView.setText(profilePreferences.getString(USERNAME, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(STATUS)) {
                statusView.setText(profilePreferences.getInt(STATUS, -1));
            }
            if (profilePreferences.contains(DATE_ADDED)) {
                stampDateView.setText(profilePreferences.getString(DATE_ADDED, NOT_AVAILABLE));
            }

            if (profilePreferences.contains(LAST_LOGIN)) {
                lastLoginView.setText(profilePreferences.getString(LAST_LOGIN, NOT_AVAILABLE));
            }
            if (profilePreferences.contains(LOGIN_TIMES)) {
                loginTimesView.setText(profilePreferences.getInt(LOGIN_TIMES, -1));
            }
        }

    }
    public  String  echoStatus(String statusCode){
        String state = NOT_AVAILABLE;
       if(!statusCode.equals("")){
           if(statusCode.equals("1")){
               state = "Active";
           }
           else{
               state = "Inactive";
           }
       }
       return state;
    }
    public String getYesNo (String boolValue){
        String yesNo = NOT_AVAILABLE;
        if(!boolValue.equals("") && !boolValue.equals("null") && !boolValue.isEmpty()){
            if(boolValue.equals("1")){
                yesNo = "Yes";
            }
            else{
                yesNo = "No";
            }
        }
        return yesNo;
    }
    public boolean validateFields(EditText[] fields)
    {
        for(EditText e : fields)
        {
            String typedText = e.getText().toString();
            return !typedText.isEmpty();
        }

        return  false;
    }


    public  boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }
    public boolean arePasswordsSame(EditText passwordField, EditText confirmPasswordField)
    {
        String enteredPassword = passwordField.getText().toString();
        String confirmPassword = confirmPasswordField.getText().toString();
        return enteredPassword.equals(confirmPassword);
    }
    public  boolean isPhoneValid (String phoneNumber)
    {
        return !(phoneNumber.isEmpty() | phoneNumber.length() < 8 | (phoneNumber.contains("+265") & phoneNumber.length() < 10));
    }
    public static void hideSoftKeyboard(AppCompatActivity activity)
    {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }
    public String decipherMetric(int indexInSpinner){
        String metricString = "N";
        if(indexInSpinner != 0){
            if(indexInSpinner != 1){
                metricString = "W";
            }
        }
        return metricString;
    }

    public String decipherProductCategory(int indexInSpinner){
        String categoryString = "3";
        if(indexInSpinner != 0){
            categoryString = String.valueOf(indexInSpinner);
        }
        return categoryString;
    }

    public void removeHint(EditText[] editTexts){
        for (EditText ed: editTexts) {
            ed.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus)
                        ed.setHint("");
                }
            });

        }

    }
}






