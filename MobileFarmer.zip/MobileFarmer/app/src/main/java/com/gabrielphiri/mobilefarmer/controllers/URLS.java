package com.gabrielphiri.mobilefarmer.controllers;

public class URLS {
    public static  String MAIN_URL = "http://41.222.185.152:7777/website_services/mobile_farmer/DataTrans.php?ExchangeToken=8a0ac46e1566208471b3&Function=";
    public static  String LIST_PRODUCTS_URL = MAIN_URL +"listProducts";
    public static final String ADD_PRODUCT_URL = MAIN_URL + "isAddingProductSuccessful";
    public static String LOGIN_URL = MAIN_URL + "isLoginSuccessful";
    public static final String PURCHASE_PRODUCT_URL =  MAIN_URL + "isPurchaseSuccessful";
    public static final String LIST_SALES_URL = MAIN_URL + "listSales";
    public static final String LIST_PURCHASES_URL = MAIN_URL + "listPurchases";
    public static final String GRANT_FULL_TRADE_URL =  MAIN_URL + "grantFullTrade";
    public static final String REGISTER_USER_URL = MAIN_URL + "isUserRegistrationSuccessful";
    public static String IMAGES_URL = "http://41.222.185.152:7777/website_services/mobile_farmer/uploads/";
    public static String PRODUCT_IMAGES_URL = IMAGES_URL + "products/";
    public static  String USER_IMAGES_URL = IMAGES_URL + "users/";
}
