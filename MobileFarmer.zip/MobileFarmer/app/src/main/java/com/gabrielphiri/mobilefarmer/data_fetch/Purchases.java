package com.gabrielphiri.mobilefarmer.data_fetch;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.gabrielphiri.mobilefarmer.R;
import com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager;
import com.gabrielphiri.mobilefarmer.controllers.URLS;
import com.gabrielphiri.mobilefarmer.controllers.User;
import com.gabrielphiri.mobilefarmer.data_trans.AddProduct;
import com.gabrielphiri.mobilefarmer.launcher.Home;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.IS_SELLER;
import static com.gabrielphiri.mobilefarmer.controllers.LogRegPrefManager.SHARED_PREF_NAME;


public class Purchases extends AppCompatActivity {

    private RecyclerView recyclerView;
    FloatingActionButton addFaultFab;
    private RecyclerView.Adapter adapter;
    private List<ProductListModel> developersLists;
    RelativeLayout flRl;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_list_recycler_view);
        setTitle(R.string.purchases);
        recyclerView =  findViewById(R.id.recyclerView);
        flRl = findViewById(R.id.flRl);
        addFaultFab = findViewById(R.id.addFaultFab);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        String isSeller = sharedPreferences.getString(IS_SELLER, "0");
        addFaultFab.setImageResource(android.R.drawable.ic_menu_sort_by_size);
        addFaultFab.setOnClickListener(v -> {
           startActivity(new Intent(Purchases.this, ListProducts.class));
        });
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        developersLists = new ArrayList<>();
        loadUrlData();
    }
    private void loadUrlData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        User userInfo = LogRegPrefManager.getInstance(this).getUserInfo();
        String buyerId = userInfo.getId();
        progressDialog.setMessage("Loading purchases...");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URLS.LIST_PURCHASES_URL+"&buyerId="+buyerId, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("purchasesList");
                    for (int i = 0; i < array.length(); i++){
                        JSONObject jo = array.getJSONObject(i);
                        ProductListModel developers =  new ProductListModel(jo.getString("productName"), "Date: "+jo.getString("dateAdded"),
                                "Qty: "+jo.getString("quantity"),
                                "Unit : "+jo.getString("unitPrice"), "Total Px: "+jo.getString("totalPrice"), jo.getString("buyerName"), jo.getString("status"), jo.getString("image"),
                                jo.getString("image") , jo.getString("id"));
                        developersLists.add(developers);
                    }
                    adapter = new ProductsListAdapter(developersLists, getApplicationContext());
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Purchases.this, "Error" + error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.purchases_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.sales: {
                startActivity(new Intent(Purchases.this, SalesList.class));
                break;
            }
            case R.id.userProfile: {
                startActivity(new Intent(Purchases.this, UserProfile.class));
                break;
            }
        }
        return true;
    }



}

